<div<?php print $attributes; ?>>
  <?php print $item; ?>
</div>

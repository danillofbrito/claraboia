<?php print $rendered_next_link; ?>

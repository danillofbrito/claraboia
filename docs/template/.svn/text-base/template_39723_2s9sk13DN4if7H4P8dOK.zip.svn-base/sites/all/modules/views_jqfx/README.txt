Views jQFX API
----------------------------

This is a simple API for integrating jQuery Plugins with views.
It does nothing on its own.

To install simply upload to your modules directory and enable it.

Modules that utilize this api include:
1) Views jQfx Cycle - a jQuery cycle mode.
2) Views jQfx Galleria - integrates the Galleria plugin.
3) Views jQfx ImageFlow - integrates the ImageFlow plugin.
4) Views jQfx Nivo-slider - integrates the Nivo-slider plugin.

Other plugins will follow.

Additional information can be found at: http://www.lunarclips.com

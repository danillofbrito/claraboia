<div<?php print $attributes; ?>>
  <?php print $rendered_rows; ?>
</div>

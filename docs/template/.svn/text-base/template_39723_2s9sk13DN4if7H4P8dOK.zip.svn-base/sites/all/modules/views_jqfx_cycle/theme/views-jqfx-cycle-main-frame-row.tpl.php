<div<?php print $attributes; ?>>
  <?php print $rendered_items; ?>
</div>
